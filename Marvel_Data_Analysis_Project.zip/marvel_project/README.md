# 🦸 Marvel Cinematic Universe (MCU) — Data Analysis Project

**A complete end-to-end data analysis project covering 80+ years of Marvel movies & TV, built for internship application portfolio.**

Author: Tayyab
Tools: Python (pandas, numpy, matplotlib) · Power BI

---

## 📌 Project Overview

This project analyzes a relational Marvel dataset spanning **161 titles** (1944–2026) across the MCU, Pre-MCU, Fox X-Men, Sony Spider-Man, and Netflix Marvel universes. It answers business-relevant questions such as:

- Which MCU phase performed best financially?
- Do bigger budgets translate into bigger box office and better ratings?
- Which titles delivered the best return on investment (ROI)?
- How have audience ratings trended over 8 decades?
- Is there a meaningful rating gap between "MCU canon" and other Marvel-related titles?

The project follows a real-world analyst workflow: **raw data → cleaning → feature engineering → exploratory analysis → visualization → BI-ready export.**

---

## 🗂️ Dataset

Source: 4 relational CSV files (`marvel_master.csv`, `marvel_cast.csv`, `marvel_ratings.csv`, `marvel_rag.csv`)

| File | Rows | Description |
|---|---|---|
| `marvel_master.csv` | 161 | Core title-level data: budget, revenue, ratings, genre, MCU phase, universe, cast summary |
| `marvel_cast.csv` | 1,628 | Actor-level cast data per title with TMDB popularity scores |
| `marvel_ratings.csv` | 554 | Long-format ratings from multiple sources (IMDb, TMDB) |
| `marvel_rag.csv` | 4,187 | Text corpus per title (used for reference, not quantitative analysis) |

---

## 🧹 Data Cleaning Process (`scripts/01_data_cleaning.py`)

1. **Type coercion** — numeric fields stored as text (e.g. `imdb_votes` with comma separators) converted to proper numeric types.
2. **Missing value handling** — literal `"N/A"` strings replaced with true nulls; boolean flags (`is_mcu_canon`, `is_tv_series`, `is_animated`) normalized.
3. **Feature engineering**:
   - `profit_usd` and `roi_pct` (return on investment)
   - `avg_critic_score_100` — a blended score combining IMDb, Rotten Tomatoes, Metacritic, and TMDB on a common 0–100 scale
   - `runtime_bucket` — categorical runtime groupings
   - `decade_calc` — decade bucket validation
4. **Merging** — lead actor (cast_order = 0) joined onto each title from the cast table; ratings pivoted from long to wide format for side-by-side comparison.
5. **Export** — clean analysis-ready CSVs written to `data_processed/`, and simplified, business-friendly tables written to `powerbi_export/` for direct Power BI import.

---

## 📊 Exploratory Analysis & Visualizations (`scripts/02_analysis_visualization.py`)

10 matplotlib visualizations were generated, saved in `/charts`:

| # | Chart | Insight |
|---|---|---|
| 1 | Titles Released per Decade | Most content (71 titles) released in the 2010s |
| 2 | Universe/Studio Distribution | MCU makes up 54.7% of all titles |
| 3 | Avg Budget vs Revenue by MCU Phase | Phase 3 had the highest average revenue per film (~$1,229M) |
| 4 | Top 10 ROI Films | *Deadpool* delivered the highest ROI (1,250%) |
| 5 | IMDb Rating Trend Over Time | Ratings improved from 5.79 avg (pre-2010) to 6.75 avg (2020+) |
| 6 | Critic Score Comparison | Rotten Tomatoes rates MCU titles highest on average (69.8/100) |
| 7 | Runtime Distribution | Average Marvel title runs 110 minutes |
| 8 | Correlation Matrix | Revenue ↔ IMDb rating correlation = 0.60 (moderately strong) |
| 9 | Top 10 Highest-Grossing Titles | *Avengers: Endgame* leads at $2.8B |
| 10 | MCU Canon vs Non-Canon Ratings | Canon titles average 6.98/10 vs. 6.13/10 for non-canon |

Full write-up available in `charts/insights_summary.txt`.

---

## 📈 Power BI Dashboard

The `powerbi_export/` folder contains 3 clean, relational tables ready for direct import into Power BI:

- **`PowerBI_Movies_Fact_Table.csv`** — one row per title with financials, ratings, and metadata (fact table)
- **`PowerBI_Cast_Table.csv`** — actor-level detail (dimension table, joins on title + year)
- **`PowerBI_Ratings_Table.csv`** — wide-format multi-source ratings (dimension table)

### Suggested Power BI report pages
1. **Overview** — KPI cards (total titles, avg rating, total box office), titles-per-decade bar chart, universe donut chart
2. **Financial Performance** — budget vs revenue by phase, ROI leaderboard, top grossing titles
3. **Critical Reception** — ratings trend line, source comparison, canon vs non-canon comparison
4. **Cast Explorer** — actor popularity table with slicers by title/year

*(Relationship model: `Movies[title+year]` → `Cast[title+year]` and `Movies[title+year]` → `Ratings[title+year]`, both one-to-many.)*

---

## 📁 Project Structure

```
marvel_project/
├── README.md
├── data_raw/                      # original CSVs, untouched
│   ├── marvel_master.csv
│   ├── marvel_cast.csv
│   ├── marvel_ratings.csv
│   └── marvel_rag.csv
├── data_processed/                 # cleaned data for Python analysis
│   ├── marvel_master_clean.csv
│   ├── marvel_cast_clean.csv
│   └── marvel_ratings_wide.csv
├── powerbi_export/                 # Power BI-ready tables
│   ├── PowerBI_Movies_Fact_Table.csv
│   ├── PowerBI_Cast_Table.csv
│   └── PowerBI_Ratings_Table.csv
├── scripts/
│   ├── 01_data_cleaning.py
│   └── 02_analysis_visualization.py
└── charts/                         # 10 exported PNG visualizations + insights_summary.txt
```

---

## 🚀 How to Run

```bash
cd scripts
python3 01_data_cleaning.py            # cleans raw data, produces processed + Power BI CSVs
python3 02_analysis_visualization.py   # generates all charts + insights summary
```

Then open Power BI Desktop → **Get Data → Text/CSV** → import the 3 files from `powerbi_export/` → build relationships on `title + year`.

---

## 💡 Notes for Presentation

This is framed as a **living, evolving project** — the MCU dataset naturally grows as new Marvel films and shows release, so the pipeline (cleaning → analysis → BI export) is built to be re-run on updated data without modification. This is a good talking point in an interview: it demonstrates the project isn't a one-off analysis but a **repeatable analytics pipeline**.

### Skills demonstrated
- Data wrangling & cleaning of messy real-world relational data (pandas, numpy)
- Feature engineering (ROI, blended scores, categorical bucketing)
- Statistical analysis (correlation, rolling averages, group aggregation)
- Data visualization best practices (labeled, titled, business-ready charts)
- BI tool integration (star-schema thinking, Power BI-ready exports)
