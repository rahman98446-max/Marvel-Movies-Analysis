"""
==========================================================
MARVEL CINEMATIC UNIVERSE (MCU) DATA ANALYSIS PROJECT
Step 2: Exploratory Data Analysis & Visualization
==========================================================
Uses: pandas, numpy, matplotlib
Outputs: PNG charts in ../charts/ + a text insights summary
==========================================================
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

OUT = "../data_processed"
CHARTS = "../charts"

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#333333",
    "axes.titlesize": 14,
    "axes.titleweight": "bold",
    "axes.labelsize": 11,
    "font.size": 10,
    "figure.dpi": 130,
})

COLOR_MAIN = "#ED1D24"     # Marvel red
COLOR_ACCENT = "#1B1B1B"   # near-black
COLOR_GOLD = "#C9A227"

df = pd.read_csv(f"{OUT}/marvel_master_clean.csv")

insights = []

def log(msg):
    print(msg)
    insights.append(msg)

log("="*70)
log("MARVEL DATASET — KEY INSIGHTS SUMMARY")
log("="*70)
log(f"Total titles analyzed: {len(df)}")
log(f"Date range: {int(df['year'].min())}–{int(df['year'].max())}")

# ----------------------------------------------------------
# CHART 1: Number of Releases per Decade
# ----------------------------------------------------------
decade_counts = df["decade"].value_counts().sort_index()
fig, ax = plt.subplots(figsize=(9, 5))
bars = ax.bar(decade_counts.index.astype(str), decade_counts.values, color=COLOR_MAIN)
ax.set_title("Marvel Titles Released per Decade")
ax.set_xlabel("Decade")
ax.set_ylabel("Number of Titles")
for b in bars:
    ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.5, int(b.get_height()),
            ha="center", fontsize=9)
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig(f"{CHARTS}/01_titles_per_decade.png")
plt.close()

top_decade = decade_counts.idxmax()
log(f"Insight 1: Most Marvel content was released in the {top_decade} ({decade_counts.max()} titles).")

# ----------------------------------------------------------
# CHART 2: Universe / Studio Distribution (Pie)
# ----------------------------------------------------------
universe_counts = df["universe"].value_counts()
fig, ax = plt.subplots(figsize=(7, 7))
colors = plt.cm.Reds_r(np.linspace(0.15, 0.75, len(universe_counts)))
ax.pie(universe_counts.values, labels=universe_counts.index, autopct="%1.0f%%",
       colors=colors, startangle=90, wedgeprops={"edgecolor": "white"})
ax.set_title("Distribution of Titles by Universe / Studio")
plt.tight_layout()
plt.savefig(f"{CHARTS}/02_universe_distribution.png")
plt.close()

log(f"Insight 2: '{universe_counts.idxmax()}' accounts for the largest share of titles "
    f"({universe_counts.max()} of {universe_counts.sum()}, {universe_counts.max()/universe_counts.sum()*100:.1f}%).")

# ----------------------------------------------------------
# CHART 3: MCU Phase — Average Budget vs Revenue
# ----------------------------------------------------------
mcu_only = df[df["is_mcu_canon"] == True].copy()
phase_order = ["Phase 1", "Phase 2", "Phase 3", "Phase 4", "Phase 5/6"]
phase_stats = (
    mcu_only[mcu_only["mcu_phase"].isin(phase_order)]
    .groupby("mcu_phase")[["budget_usd", "revenue_usd"]]
    .mean()
    .reindex(phase_order)
)

fig, ax = plt.subplots(figsize=(10, 5.5))
x = np.arange(len(phase_stats))
width = 0.35
ax.bar(x - width/2, phase_stats["budget_usd"]/1e6, width, label="Avg Budget ($M)", color=COLOR_ACCENT)
ax.bar(x + width/2, phase_stats["revenue_usd"]/1e6, width, label="Avg Revenue ($M)", color=COLOR_MAIN)
ax.set_xticks(x)
ax.set_xticklabels(phase_stats.index)
ax.set_ylabel("USD (Millions)")
ax.set_title("Average Budget vs Revenue by MCU Phase")
ax.legend()
plt.tight_layout()
plt.savefig(f"{CHARTS}/03_budget_vs_revenue_by_phase.png")
plt.close()

best_phase = phase_stats["revenue_usd"].idxmax()
log(f"Insight 3: {best_phase} generated the highest average revenue per film "
    f"(${phase_stats['revenue_usd'].max()/1e6:,.0f}M avg).")

# ----------------------------------------------------------
# CHART 4: ROI Leaders (Top 10 by ROI %)
# ----------------------------------------------------------
roi_df = df.dropna(subset=["roi_pct"])
roi_df = roi_df[roi_df["budget_usd"] > 1_000_000]  # filter out noise/near-zero budgets
top_roi = roi_df.nlargest(10, "roi_pct")[["title", "year", "roi_pct"]].iloc[::-1]

fig, ax = plt.subplots(figsize=(9, 6))
bars = ax.barh(top_roi["title"] + " (" + top_roi["year"].astype(int).astype(str) + ")",
                top_roi["roi_pct"], color=COLOR_GOLD)
ax.set_title("Top 10 Films by Return on Investment (ROI %)")
ax.set_xlabel("ROI (%)")
for b in bars:
    ax.text(b.get_width() + 5, b.get_y() + b.get_height()/2, f"{b.get_width():,.0f}%",
            va="center", fontsize=9)
plt.tight_layout()
plt.savefig(f"{CHARTS}/04_top10_roi.png")
plt.close()

log(f"Insight 4: '{top_roi.iloc[-1]['title']}' delivered the highest ROI in the dataset "
    f"at {top_roi.iloc[-1]['roi_pct']:,.0f}%.")

# ----------------------------------------------------------
# CHART 5: Ratings Trend Over Time (IMDb) with rolling average
# ----------------------------------------------------------
yearly = df.dropna(subset=["imdb_rating"]).groupby("year")["imdb_rating"].mean().sort_index()
rolling = yearly.rolling(5, min_periods=1).mean()

fig, ax = plt.subplots(figsize=(11, 5.5))
ax.scatter(yearly.index, yearly.values, color=COLOR_ACCENT, alpha=0.5, s=25, label="Yearly Avg IMDb Rating")
ax.plot(rolling.index, rolling.values, color=COLOR_MAIN, linewidth=2.5, label="5-Year Rolling Average")
ax.set_title("Marvel Titles: IMDb Rating Trend Over Time")
ax.set_xlabel("Year")
ax.set_ylabel("IMDb Rating")
ax.legend()
plt.tight_layout()
plt.savefig(f"{CHARTS}/05_imdb_rating_trend.png")
plt.close()

recent_avg = yearly[yearly.index >= 2020].mean()
early_avg = yearly[yearly.index < 2010].mean()
trend_word = "declined" if recent_avg < early_avg else "improved"
log(f"Insight 5: Average IMDb ratings have {trend_word} — pre-2010 avg was {early_avg:.2f} "
    f"vs. {recent_avg:.2f} from 2020 onward.")

# ----------------------------------------------------------
# CHART 6: Critic Score Comparison (IMDb vs RT vs Metacritic) — MCU only
# ----------------------------------------------------------
score_compare = mcu_only[["imdb_rating_100", "rt_score", "metacritic_score"]].mean()
labels = ["IMDb (x10)", "Rotten Tomatoes", "Metacritic"]
fig, ax = plt.subplots(figsize=(7, 5))
bars = ax.bar(labels, score_compare.values, color=[COLOR_MAIN, COLOR_GOLD, COLOR_ACCENT])
ax.set_title("Average Critic Scores — MCU Titles (normalized to 100)")
ax.set_ylabel("Score (0-100)")
ax.set_ylim(0, 100)
for b in bars:
    ax.text(b.get_x() + b.get_width()/2, b.get_height() + 1, f"{b.get_height():.1f}", ha="center")
plt.tight_layout()
plt.savefig(f"{CHARTS}/06_critic_score_comparison.png")
plt.close()

log(f"Insight 6: Among rating sources, "
    f"{labels[np.argmax(score_compare.values)]} scores MCU titles highest on average "
    f"({score_compare.max():.1f}/100).")

# ----------------------------------------------------------
# CHART 7: Runtime Distribution (Histogram)
# ----------------------------------------------------------
fig, ax = plt.subplots(figsize=(9, 5))
ax.hist(df["runtime_min"].dropna(), bins=20, color=COLOR_MAIN, edgecolor="white")
mean_rt = df["runtime_min"].mean()
ax.axvline(mean_rt, color=COLOR_ACCENT, linestyle="--", linewidth=2, label=f"Mean = {mean_rt:.0f} min")
ax.set_title("Distribution of Runtimes Across Marvel Titles")
ax.set_xlabel("Runtime (minutes)")
ax.set_ylabel("Number of Titles")
ax.legend()
plt.tight_layout()
plt.savefig(f"{CHARTS}/07_runtime_distribution.png")
plt.close()

log(f"Insight 7: The average Marvel title runs {mean_rt:.0f} minutes.")

# ----------------------------------------------------------
# CHART 8: Correlation Heatmap-style (Budget, Revenue, Ratings, Popularity)
# ----------------------------------------------------------
corr_cols = ["budget_usd", "revenue_usd", "imdb_rating", "rt_score", "metacritic_score", "popularity", "roi_pct"]
corr = df[corr_cols].corr()

fig, ax = plt.subplots(figsize=(8, 7))
im = ax.imshow(corr.values, cmap="RdGy_r", vmin=-1, vmax=1)
ax.set_xticks(range(len(corr_cols)))
ax.set_yticks(range(len(corr_cols)))
ax.set_xticklabels(corr_cols, rotation=45, ha="right")
ax.set_yticklabels(corr_cols)
for i in range(len(corr_cols)):
    for j in range(len(corr_cols)):
        ax.text(j, i, f"{corr.values[i,j]:.2f}", ha="center", va="center",
                color="white" if abs(corr.values[i,j]) > 0.5 else "black", fontsize=8)
ax.set_title("Correlation Matrix: Budget, Revenue, Ratings & Popularity")
fig.colorbar(im, ax=ax, shrink=0.8)
plt.tight_layout()
plt.savefig(f"{CHARTS}/08_correlation_matrix.png")
plt.close()

rev_rating_corr = corr.loc["revenue_usd", "imdb_rating"]
strength = 'weak' if abs(rev_rating_corr) < 0.3 else 'moderate' if abs(rev_rating_corr) < 0.6 else 'strong'
log(f"Insight 8: Correlation between revenue and IMDb rating is {rev_rating_corr:.2f} ({strength}) "
    "— bigger box office numbers tend to go hand-in-hand with better audience reception, though plenty of exceptions exist.")

# ----------------------------------------------------------
# CHART 9: Top 10 Highest-Grossing Titles
# ----------------------------------------------------------
top_gross = df.dropna(subset=["box_office_final"]).nlargest(10, "box_office_final")[["title", "year", "box_office_final"]].iloc[::-1]
fig, ax = plt.subplots(figsize=(9, 6))
bars = ax.barh(top_gross["title"] + " (" + top_gross["year"].astype(int).astype(str) + ")",
                top_gross["box_office_final"]/1e6, color=COLOR_MAIN)
ax.set_title("Top 10 Highest-Grossing Marvel Titles")
ax.set_xlabel("Box Office Revenue ($ Millions)")
for b in bars:
    ax.text(b.get_width() + 20, b.get_y() + b.get_height()/2, f"${b.get_width():,.0f}M", va="center", fontsize=8)
plt.tight_layout()
plt.savefig(f"{CHARTS}/09_top10_highest_grossing.png")
plt.close()

log(f"Insight 9: '{top_gross.iloc[-1]['title']}' ({int(top_gross.iloc[-1]['year'])}) is the highest-grossing "
    f"Marvel title at ${top_gross.iloc[-1]['box_office_final']/1e6:,.0f}M.")

# ----------------------------------------------------------
# CHART 10: MCU Canon vs Non-Canon — average rating comparison
# ----------------------------------------------------------
canon_compare = df.groupby("is_mcu_canon")["imdb_rating"].mean()
fig, ax = plt.subplots(figsize=(6, 5))
bars = ax.bar(["Non-MCU-Canon", "MCU Canon"], canon_compare.values, color=[COLOR_ACCENT, COLOR_MAIN])
ax.set_title("Average IMDb Rating: MCU Canon vs Non-Canon")
ax.set_ylabel("IMDb Rating")
ax.set_ylim(0, 10)
for b in bars:
    ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.1, f"{b.get_height():.2f}", ha="center")
plt.tight_layout()
plt.savefig(f"{CHARTS}/10_canon_vs_noncanon_rating.png")
plt.close()

log(f"Insight 10: MCU canon titles average {canon_compare[True]:.2f}/10 on IMDb vs. "
    f"{canon_compare[False]:.2f}/10 for non-canon Marvel-related titles.")

# ----------------------------------------------------------
# SAVE INSIGHTS TO FILE
# ----------------------------------------------------------
with open(f"{CHARTS}/insights_summary.txt", "w") as f:
    f.write("\n".join(insights))

print("\n✅ All 10 charts + insights_summary.txt saved to /charts")
