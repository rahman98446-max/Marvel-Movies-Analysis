"""
==========================================================
MARVEL CINEMATIC UNIVERSE (MCU) DATA ANALYSIS PROJECT
Step 1: Data Loading & Cleaning
==========================================================
Author: Tayyab
Purpose: Internship data analysis portfolio project

This script:
  1. Loads all 4 raw Marvel datasets
  2. Cleans and standardizes data types
  3. Handles missing values sensibly
  4. Engineers new features (ROI, profit, decade buckets, etc.)
  5. Merges datasets into analysis-ready tables
  6. Exports clean CSVs for Python analysis AND Power BI
==========================================================
"""

import pandas as pd
import numpy as np
import os

RAW = "../data_raw"
OUT = "../data_processed"
PBI = "../powerbi_export"

pd.set_option("display.width", 140)

# ----------------------------------------------------------
# 1. LOAD RAW DATA
# ----------------------------------------------------------
master = pd.read_csv(f"{RAW}/marvel_master.csv")
cast = pd.read_csv(f"{RAW}/marvel_cast.csv")
ratings = pd.read_csv(f"{RAW}/marvel_ratings.csv")
# rag file is a text/RAG corpus (not used for quantitative analysis)

print("Raw shapes ->", "master:", master.shape, "| cast:", cast.shape, "| ratings:", ratings.shape)

# ----------------------------------------------------------
# 2. CLEAN MASTER TABLE
# ----------------------------------------------------------
df = master.copy()

# Numeric coercion (some numeric-looking cols may have 'N/A' strings)
numeric_cols = ["runtime_min", "imdb_rating", "rt_score", "metacritic_score",
                 "box_office_usd", "budget_usd", "revenue_usd", "tmdb_rating",
                 "tmdb_votes", "popularity", "age_years"]
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# imdb_votes has commas as thousands separators -> clean to numeric
df["imdb_votes"] = (
    df["imdb_votes"].astype(str).str.replace(",", "", regex=False)
)
df["imdb_votes"] = pd.to_numeric(df["imdb_votes"], errors="coerce")

# Replace literal "N/A" strings across object columns with real NaN
obj_cols = df.select_dtypes(include="object").columns
df[obj_cols] = df[obj_cols].replace("N/A", np.nan)

# Boolean-style flags -> proper booleans
for flag in ["is_animated", "is_tv_series", "is_mcu_canon"]:
    df[flag] = df[flag].fillna(0).astype(int).astype(bool)

# ----------------------------------------------------------
# 3. FEATURE ENGINEERING
# ----------------------------------------------------------
# Profit & ROI only make sense where both budget & revenue are known and budget > 0
df["profit_usd"] = df["revenue_usd"] - df["budget_usd"]
df["roi_pct"] = np.where(
    df["budget_usd"] > 0,
    (df["profit_usd"] / df["budget_usd"]) * 100,
    np.nan
)

# Consolidated "best available" box office figure
# (prefer TMDB revenue_usd, fall back to box_office_usd column)
df["box_office_final"] = df["revenue_usd"].where(df["revenue_usd"] > 0, df["box_office_usd"])

# Average critic score (blend IMDb 0-10, RT 0-100, Metacritic 0-100, TMDB 0-10)
df["imdb_rating_100"] = df["imdb_rating"] * 10
df["tmdb_rating_100"] = df["tmdb_rating"] * 10
df["avg_critic_score_100"] = df[["imdb_rating_100", "rt_score", "metacritic_score", "tmdb_rating_100"]].mean(axis=1, skipna=True)

# Simple decade bucket cross-check (recompute independent of provided 'decade' col)
df["decade_calc"] = (df["year"] // 10 * 10).astype("Int64").astype(str) + "s"

# Runtime buckets
df["runtime_bucket"] = pd.cut(
    df["runtime_min"],
    bins=[0, 90, 120, 150, 999],
    labels=["<90 min", "90-120 min", "120-150 min", "150+ min"]
)

print("\nCleaned master table info:")
print(df.dtypes.value_counts())
print("Missing budget/revenue rows:", df["budget_usd"].isna().sum(), "/", len(df))

# ----------------------------------------------------------
# 4. CLEAN RATINGS (long format: title/year/source/score)
# ----------------------------------------------------------
ratings_clean = ratings.dropna(subset=["score"]).copy()
ratings_clean["score"] = pd.to_numeric(ratings_clean["score"], errors="coerce")

# Pivot to wide format for easy comparison per title
ratings_wide = ratings_clean.pivot_table(
    index=["title", "year"], columns="source", values="score", aggfunc="mean"
).reset_index()
ratings_wide.columns.name = None

# ----------------------------------------------------------
# 5. CLEAN CAST TABLE
# ----------------------------------------------------------
cast_clean = cast.copy()
cast_clean["popularity"] = pd.to_numeric(cast_clean["popularity"], errors="coerce")
cast_clean = cast_clean.dropna(subset=["actor_name"])
# Lead actor = cast_order 0 (first-billed)
lead_actors = cast_clean[cast_clean["cast_order"] == 0][["title", "year", "actor_name", "character"]]
lead_actors = lead_actors.rename(columns={"actor_name": "lead_actor", "character": "lead_character"})

# ----------------------------------------------------------
# 6. MERGE FOR A MASTER ANALYSIS TABLE
# ----------------------------------------------------------
analysis_df = df.merge(lead_actors, on=["title", "year"], how="left")

# ----------------------------------------------------------
# 7. EXPORT CLEAN DATA (Python pickle/csv for analysis + Power BI CSVs)
# ----------------------------------------------------------
os.makedirs(OUT, exist_ok=True)
os.makedirs(PBI, exist_ok=True)

analysis_df.to_csv(f"{OUT}/marvel_master_clean.csv", index=False)
cast_clean.to_csv(f"{OUT}/marvel_cast_clean.csv", index=False)
ratings_wide.to_csv(f"{OUT}/marvel_ratings_wide.csv", index=False)

# Power BI-ready star-schema style exports (simplified, business-friendly column names)
pbi_movies = analysis_df[[
    "id", "title", "year", "type", "mcu_phase", "universe", "decade",
    "genre", "director", "runtime_min", "runtime_bucket",
    "budget_usd", "revenue_usd", "box_office_final", "profit_usd", "roi_pct",
    "imdb_rating", "rt_score", "metacritic_score", "tmdb_rating", "avg_critic_score_100",
    "is_mcu_canon", "is_animated", "is_tv_series", "lead_actor"
]].rename(columns={
    "box_office_final": "box_office_usd_final",
    "avg_critic_score_100": "avg_critic_score_(0-100)"
})
pbi_movies.to_csv(f"{PBI}/PowerBI_Movies_Fact_Table.csv", index=False)

pbi_cast = cast_clean[["title", "year", "actor_name", "character", "cast_order", "popularity"]]
pbi_cast.to_csv(f"{PBI}/PowerBI_Cast_Table.csv", index=False)

pbi_ratings = ratings_wide
pbi_ratings.to_csv(f"{PBI}/PowerBI_Ratings_Table.csv", index=False)

print("\n✅ Cleaning complete. Files written to data_processed/ and powerbi_export/")
print(analysis_df.shape)
